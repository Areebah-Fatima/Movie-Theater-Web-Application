
package ejb;

// Imports
import entity.Movie;
import entity.Theater;
import entity.Timing;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


@Stateless
public class MovieBean {
    

    // Persistence context to keep track of any changes made into a managed entity
    @PersistenceContext(unitName = "FinalProjectPU")
    private EntityManager em;
    
    // to persisting objects
    public void persist(Object object) {
        em.persist(object);
    }

    // Will Use name query in theaters entity class to find a list of all theaters (find all)
    public List<Theater> findAllTheaters()
    {
        Query q = em.createNamedQuery("Theater.findAll", Theater.class);
        
        return q.getResultList();
          
    }
    
    // Will Use name query in movie entity class to find a list of all movies (find all)
    public List<Movie> findAllMovies()
    {
         return em.createNamedQuery("Movie.findAll", Movie.class).getResultList(); 
    }
    
    // returns a theater from location name using name query
    public Theater getTheater(String location)
    {

        return em.createNamedQuery("Theater.findByLocation", Theater.class)
                .setParameter("location", location)
                .getSingleResult();
    }
       
    // returns a list of all theaters for a given zip using name query
    public List<Theater> findAllTheatersForZip(String zip)
    {

        return em.createNamedQuery("Theater.findByZip", Theater.class)
                .setParameter("zip", zip)
                .getResultList();
    }
    
    // returns a list of movies for a given theater location using name query
    public List<Movie> findAllMovieForTheater(String location)
    {

        return em.createNamedQuery("Movie.findMoviesByTheater", Movie.class)
                .setParameter("location", location)
                .getResultList();
    }
    
    public Timing getShowtime(String showtime)
    {

        return em.createNamedQuery("Timing.findByShowTime", Timing.class)
                .setParameter("showtime", showtime)
                .getSingleResult();
    }
    
     // returns all items in the timing entity using name query Timing.findAll
    public List<Timing> findAllTiming()
    {

        return em.createNamedQuery("Timing.findAll", Timing.class).getResultList(); 

    }
 
    
}
