
package entity;

//Imports
import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.Size;


// Named queries (depending on query they will return all table info, id, movie-title, movie-rating, movie-runtime, movie-release, description, image-link, or movies showed by a given theater location)
@Entity
@NamedQueries({
    @NamedQuery(name = "Movie.findAll", query = "SELECT m FROM Movie m"),
    @NamedQuery(name = "Movie.findById", query = "SELECT m FROM Movie m WHERE m.id = :id"),
    @NamedQuery(name = "Movie.findByTitle", query = "SELECT m FROM Movie m WHERE m.title = :title"),
    @NamedQuery(name = "Movie.findByRating", query = "SELECT m FROM Movie m WHERE m.rating = :rating"),
    @NamedQuery(name = "Movie.findByRuntime", query = "SELECT m FROM Movie m WHERE m.runtime = :runtime"),
    @NamedQuery(name = "Movie.findByReleaseDate", query = "SELECT m FROM Movie m WHERE m.releaseDate = :releaseDate"),
    @NamedQuery(name = "Movie.findByDescription", query = "SELECT m FROM Movie m WHERE m.description = :description"),
    @NamedQuery(name = "Movie.findByImage", query = "SELECT m FROM Movie m WHERE m.image = :image"),
    @NamedQuery(name = "Movie.findMoviesByTheater", query = "SELECT m FROM Movie m, ShowedBy s WHERE m.title = s.showedByPK.title and s.showedByPK.location = :location")})

public class Movie implements Serializable {

    private static final long serialVersionUID = 1L;
    
    
    private Integer id;
    
    // Title is entity id (varchar 500)
    @Id
    @Size(max = 500)
    private String title;
    
    // movie rating varchar 15)
    @Size(max = 15)
    private String rating;
    
    // movie runtime varchar 15)
    @Size(max = 15)
    private String runtime;
    
    // movie release varchar 15)
    @Size(max = 15)
    private String releaseDate;
    
    // movie description varchar 1000
    @Size(max = 1000)
    private String description;
    
    // movie image line varchar 1000
    @Size(max = 1000)
    private String image;
    
    // Holds list of theaters
    private List<Theater> theaterList;

    // Default constructor
    public Movie() {
    }

    // takes in title
    public Movie(String title) {
        this.title = title;
    }

    // takes in id and title
    public Movie(Integer id, String title) {
        this.title = title;
        this.id = id;
    }

    // Getter and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getRuntime() {
        return runtime;
    }

    public void setRuntime(String runtime) {
        this.runtime = runtime;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Theater> getTheaterList() {
        return theaterList;
    }

    public void setTheaterList(List<Theater> theaterList) {
        this.theaterList = theaterList;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
 
    // Make sure to change this ide generated code to match entity id
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (title != null ? title.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movie)) {
            return false;
        }
        Movie other = (Movie) object;
        if ((this.title == null && other.title != null) || (this.title != null && !this.title.equals(other.title))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Movie[ title=" + title + " ]";
    }
    
}
