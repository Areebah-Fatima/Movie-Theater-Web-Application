
package entity;

// Imports
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.EmbeddedId;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.Size;

// Named queries (depending on query they will return all table info, theater location (using showedByPK), title (using showedByPK))
@Entity
@NamedQueries({
    @NamedQuery(name = "ShowedBy.findAll", query = "SELECT s FROM ShowedBy s"),
    @NamedQuery(name = "ShowedBy.findByLocation", query = "SELECT s FROM ShowedBy s WHERE s.showedByPK.location = :location"),
    @NamedQuery(name = "ShowedBy.findByTitle", query = "SELECT s FROM ShowedBy s WHERE s.showedByPK.title = :title")})
public class ShowedBy implements Serializable {

    private static final long serialVersionUID = 1L;
    
    // denote a composite primary key that is an embeddable class
    @EmbeddedId
    protected ShowedByPK showedByPK;

    // Default constructor
    public ShowedBy() {
    }

    // constructor
    public ShowedBy(ShowedByPK showedByPK) {
        this.showedByPK = showedByPK;
    }
    
    // constructor
    public ShowedBy(String location, String title) {
        this.showedByPK = new ShowedByPK(location, title);
    }

    // Getter and Setters
    public ShowedByPK getShowedByPK() {
        return showedByPK;
    }

    public void setShowedByPK(ShowedByPK showedByPK) {
        this.showedByPK = showedByPK;
    }

    // Make sure to change this ide generated code to match entity id (in this case embedded ID)
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (showedByPK != null ? showedByPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ShowedBy)) {
            return false;
        }
        ShowedBy other = (ShowedBy) object;
        if ((this.showedByPK == null && other.showedByPK != null) || (this.showedByPK != null && !this.showedByPK.equals(other.showedByPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.ShowedBy[ showedByPK=" + showedByPK + " ]";
    }
    
}
