
package entity;

// Imports
import java.io.Serializable;
import javax.persistence.Embeddable;
import javax.validation.constraints.Size;

// embeddable class must be annotated as such
@Embeddable
public class ShowedByPK implements Serializable {

    // location name should be up to 100 characters
    @Size(max = 100)
    private String location;
    
    // title name should be up to 500 characters
    @Size(max = 500)
    private String title;

    // Default contructor
    public ShowedByPK() {
    }

    // contructor
    public ShowedByPK(String location, String title) {
        this.location = location;
        this.title = title;
    }

    // Getters and setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    
    // Make sure to change this ide generated code to match entity id
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (location != null ? location.hashCode() : 0);
        hash += (title != null ? title.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ShowedByPK)) {
            return false;
        }
        ShowedByPK other = (ShowedByPK) object;
        if ((this.location == null && other.location != null) || (this.location != null && !this.location.equals(other.location))) {
            return false;
        }
        if ((this.title == null && other.title != null) || (this.title != null && !this.title.equals(other.title))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.ShowedByPK[ location=" + location + ", title=" + title + " ]";
    }
    
    
}
