
package entity;

// Imports
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.Size;

// Named queries (depending on query they will return all table info or showtimes)
@Entity
@NamedQueries({
    @NamedQuery(name = "Timing.findAll", query = "SELECT t FROM Timing t"),
    @NamedQuery(name = "Timing.findByShowTime", query = "SELECT t FROM Timing t WHERE t.showtime = :showtime")})
public class Timing implements Serializable {

    private static final long serialVersionUID = 1L;
    
    // Id for entity (varchar 50)
    @Id
    @Size(max = 50)
    private String showtime;

    // Getter / Setter
    public String getShowtime() {
        return showtime;
    }

    public void setShowtime(String showtime) {
        this.showtime = showtime;
    }
    
    

    // Make sure to change this ide generated code to match entity id
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (showtime != null ? showtime.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Timing)) {
            return false;
        }
        Timing other = (Timing) object;
        if ((this.showtime == null && other.showtime != null) || (this.showtime != null && !this.showtime.equals(other.showtime))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Timing[ showtime=" + showtime + " ]";
    }
    
}
