
package entity;

// imports
import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.Size;

// Named queries (depending on query they will return all table info, id, zip, or location name)
@Entity
@NamedQueries({
    @NamedQuery(name = "Theater.findAll", query = "SELECT t FROM Theater t"),
    @NamedQuery(name = "Theater.findById", query = "SELECT t FROM Theater t WHERE t.id = :id"),
    @NamedQuery(name = "Theater.findByZip", query = "SELECT t FROM Theater t WHERE t.zip = :zip"),
    @NamedQuery(name = "Theater.findByLocation", query = "SELECT t FROM Theater t WHERE t.location = :location"),
})

public class Theater implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Integer id;

    // holds zip varchar 5
    @Size(max = 5)
    private String zip;
    
    // Id for entity is location
    @Id
    @Size(max = 100)
    private String location;
    
    // address String varchar 100
    @Size(max = 100)
    private String address;
    
    // Holds list of movies
    private List<Movie> movies;

    
    // Getter/Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Make sure to change this ide generated code to match entity id
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (location != null ? location.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Theater)) {
            return false;
        }
        Theater other = (Theater) object;
        if ((this.location == null && other.location != null) || (this.location != null && !this.location.equals(other.location))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Theater[ location=" + location + " ]";
    }
    
}
