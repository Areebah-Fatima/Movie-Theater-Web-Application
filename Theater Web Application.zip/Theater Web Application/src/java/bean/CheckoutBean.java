
package bean;

// Imports
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

// CDI Bean for the checkout process (Session scoped to pass the info pass mutiple pages)
@Named(value = "checkoutBean")
@SessionScoped
public class CheckoutBean implements Serializable {

    private String CardNumber; // Holds card number
    private String BillingZip; // Card billing address
    private String SecurityCode; // Card Security Code
    private String Month; // Card Experation Date
    private String Year; // Card Experation Date
    private String result; // For error messages

    // Getter and Setters (To access fields in jsf pages ex: #{mainPageBean.zip})
    public String getCardNumber() {
        return CardNumber;
    }

    public void setCardNumber(String CardNumber) {
        this.CardNumber = CardNumber;
    }

    public String getBillingZip() {
        return BillingZip;
    }

    public void setBillingZip(String BillingZip) {
        this.BillingZip = BillingZip;
    }

    public String getSecurityCode() {
        return SecurityCode;
    }

    public void setSecurityCode(String SecurityCode) {
        this.SecurityCode = SecurityCode;
    }

    public String getMonth() {
        return Month;
    }

    public void setMonth(String Month) {
        this.Month = Month;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String Year) {
        this.Year = Year;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    // This function's purpose is to validate that the user gives valid inputs on the checkout page
    public String checkCheckOutInfo(){
        
        // If true it means the user didn't fill the card number field
        if(CardNumber.isEmpty()){
            
            // Display a error message 
            result = "Card Number is a required field";

            // Don't switch to next page
            return "";
            
        }
        
        // If true it means the user's entered card number isn't long enough
        if(CardNumber.length() != 16){
            
            // Display a error message 
            result = "Card Number must be 16 digits long ";

            // Don't switch to next page
            return "";
            
        }
        
        // If true it means the user added a invalid character to the card number
        if (!(CardNumber.chars().allMatch(Character::isDigit))) { 
                
            // Display a error message 
            result = "Card Number must only contain numbers";
            // Don't switch to next page
            return "";
        }

        // If true it means the user didn't fill the zip field
        if(BillingZip.isEmpty()){
            
            // Display a error message 
            result = "Billing Zip is a required field";
            // Don't switch to next page
            return "";
            
        }
        
        // If true it means the user's entered zip isn't long enough
        if(BillingZip.length() != 5){
            
            // Display a error message 
            result = "Billing Zip must be 5 digits long ";
            // Don't switch to next page
            return "";
            
        }
        
        // If true it means the user added a invalid character to the zip
        if (!(BillingZip.chars().allMatch(Character::isDigit))) { 
                
            // Display a error message 
            result = "Billing Zip must only contain numbers";
            // Don't switch to next page            
            return "";
        }

        // If true it means the user didn't fill the security code field
        if(SecurityCode.isEmpty()){
            
            // Display a error message 
            result = "Security Code is a required field";
            // Don't switch to next page
            return "";
            
        }
        
        // If true it means the user's entered security code isn't long enough
        if(SecurityCode.length() != 3){
            
            // Display a error message 
            result = "Security Code must be 3 digits long ";
            // Don't switch to next page
            return "";
            
        }
        
        // If true it means the user added a invalid character to the Security Code
        if (!(SecurityCode.chars().allMatch(Character::isDigit))) { 
                
            // Display a error message 
            result = "Security Code must only contain numbers";
            // Don't switch to next page           
            return "";
        }
   
        // If we end up here there were no issues with the input (proceed as normal) move to next page
        else{
            
            return "ThankyouPage.xhtml";
        }
        
    }

    // Default constructor
    public CheckoutBean() {
    }
    
}
