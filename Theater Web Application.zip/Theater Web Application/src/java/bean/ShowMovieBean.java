
package bean;

// Imports
import ejb.MovieBean;
import entity.Movie;
import entity.Theater;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;

// CDI Bean for the movie list (Session scoped to pass the info pass mutiple pages)
@Named(value = "showMovieBean")
@SessionScoped
public class ShowMovieBean implements Serializable {

    // Enterprise java bean from MovieBean.java 
    @EJB
    private MovieBean movieEJB;
    private Theater location;   // holds the theater they want to see movie list for
    
    // Default constructor
    public ShowMovieBean() {
    }

    // Getter and Setters (To access fields in jsf pages ex: #{mainPageBean.zip})
    public MovieBean getMovieEJB() {
        return movieEJB;
    }

    public void setMovieEJB(MovieBean movieEJB) {
        this.movieEJB = movieEJB;
    }

    public Theater getLocation() {
        return location;
    }

    public void setLocation(Theater location) {
        this.location = location;
    }


    // Function to call movie list page
    public String showMovie(Theater location) {
        this.location = location;
        return "ShowMovies.xhtml";
    }
}

