
package bean;

// imports
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import ejb.MovieBean;
import entity.Movie;
import entity.Theater;
import java.util.List;
import java.util.regex.Pattern;
import javax.ejb.EJB;
import javax.inject.Named;

// CDI Bean for the mainPage (theater list) process (Session scoped to pass the info pass mutiple pages)
@Named(value = "mainPageBean")
@SessionScoped
public class MainPageBean implements Serializable {

    // Enterprise java bean from MovieBean.java 
    @EJB
    private MovieBean movieEJB;
    
    private String zip; // user's zip
    private String location; // theater location selected
    private String result; // For error messages
    private Boolean isNull; // flag

    // Getter and Setters (To access fields in jsf pages ex: #{mainPageBean.zip})
    public MovieBean getMovieEJB() {
        return movieEJB;
    }

    public void setMovieEJB(MovieBean movieEJB) {
        this.movieEJB = movieEJB;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Boolean getIsNull() {
        return isNull;
    }

    public void setIsNull(Boolean isNull) {
        this.isNull = isNull;
    }

    // Default constructor
    public MainPageBean() {
    }
    
    // This function's purpose is to validate that the user gives valid inputs on the search for theaters page
    public String checkZip(){

        // If true it means the user didn't enter a zip
        if(movieEJB.findAllTheatersForZip(zip).isEmpty()){
            
            // Display error message
            result = "Provided zip yields no results";
            
            // check that if the user entered a value that it meets the size req.
            if(zip.length() != 5){
            
            // Display error message
            result = "Zip is a required field and must be 5 digits long ";

            // Stay on same page
            return "";
            
            }
            
            // If true it means the user added a invalid character to the zip
            if (!(zip.chars().allMatch(Character::isDigit))) { 
                
            // Display error message
            result = "Zip must only contain numbers";
            // Stay on same page
            return "";
            }
            
            // Stay on same page (because of an error we don't want to progress)
            return "";
        }
        
        // Otherwise we have no issue move to next page
        else{
            
            return "MainPage.xhtml";
        }

    }
    
    // Returns list of theaters
    public List<Theater> getTheaterList()
    {
        // call movie EJB function that will call a named query for theaters to a zip
        return movieEJB.findAllTheatersForZip(zip);
        
    }
    
    // returns list of movies
    public List<Movie> getMovieList(String Searchlocation)
    {
        // call movie EJB function that will call a named query for movies at a certain theater location (that's passed)
        return movieEJB.findAllMovieForTheater(Searchlocation);
        
      
 
    }

}

