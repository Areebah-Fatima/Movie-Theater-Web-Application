
package bean;

// Imports
import ejb.MovieBean;
import entity.Movie;
import entity.Theater;
import entity.Timing;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import javax.ejb.EJB;

// CDI Bean for the movie description page and billing process (Session scoped to pass the info pass mutiple pages)
@Named(value = "showDescriptionBean")
@SessionScoped
public class ShowDescriptionBean implements Serializable {

    // Enterprise java bean from MovieBean.java 
    @EJB
    private MovieBean movieEJB;
    private Movie title;    // title for certain movie
    private String showtime; // holds user selected showtime
    private Integer quantity; // number of ticket user wants
    private Integer total; // user total (quantity * 10)
    private String result; // For error messages

    // Default constructor
    public ShowDescriptionBean() {
    }


    // Getter and Setters (To access fields in jsf pages ex: #{mainPageBean.zip})
    public MovieBean getMovieEJB() {
        return movieEJB;
    }

    public void setMovieEJB(MovieBean movieEJB) {
        this.movieEJB = movieEJB;
    }

    public Movie getTitle() {
        return title;
    }

    public void setTitle(Movie title) {
        this.title = title;
    }

    public String getShowtime() {
        return showtime;
    }

    public void setShowtime(String showtime) {
        this.showtime = showtime;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        
        // return number of tickets * $10
        this.total = (quantity*10);
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    // Function to call movie info page
    public String showDescription(Movie title) {
        this.title = title;
        return "ShowDescription.xhtml";
    }
    
    // Function to call timing page
    public String showTimingPage() {
       
        return "ShowTimesPage.xhtml";
    }
    
    // returns list of all show timing
    public List<Timing> getShowTimeList()
    {
        // call movie EJB function that will call a named query for all show timings
        return movieEJB.findAllTiming();
    }
    
    // This function's purpose is to validate that the user gives valid inputs on the show times page
    public String checkInfo(){
        
        
        // If true the quantity provided is null or non logical
        if(quantity <=0){
            
            // error message
            result = "Quantity is a required field and must be a value greater than 0";

            // stay on same page
            return "";
            
        }

        // If we end up here there were no issues with the input (proceed as normal) move to next page
        else{
            
            return "CheckOutPage.xhtml";
        }
        
    }
    
}
